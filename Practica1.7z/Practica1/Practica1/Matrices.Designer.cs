﻿namespace Practica1
{
    partial class Matrices
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.m11 = new System.Windows.Forms.TextBox();
            this.m12 = new System.Windows.Forms.TextBox();
            this.m13 = new System.Windows.Forms.TextBox();
            this.m15 = new System.Windows.Forms.TextBox();
            this.m14 = new System.Windows.Forms.TextBox();
            this.m25 = new System.Windows.Forms.TextBox();
            this.m24 = new System.Windows.Forms.TextBox();
            this.m23 = new System.Windows.Forms.TextBox();
            this.m22 = new System.Windows.Forms.TextBox();
            this.m21 = new System.Windows.Forms.TextBox();
            this.m35 = new System.Windows.Forms.TextBox();
            this.m34 = new System.Windows.Forms.TextBox();
            this.m33 = new System.Windows.Forms.TextBox();
            this.m32 = new System.Windows.Forms.TextBox();
            this.m31 = new System.Windows.Forms.TextBox();
            this.m45 = new System.Windows.Forms.TextBox();
            this.m44 = new System.Windows.Forms.TextBox();
            this.m43 = new System.Windows.Forms.TextBox();
            this.m42 = new System.Windows.Forms.TextBox();
            this.m41 = new System.Windows.Forms.TextBox();
            this.m55 = new System.Windows.Forms.TextBox();
            this.m54 = new System.Windows.Forms.TextBox();
            this.m53 = new System.Windows.Forms.TextBox();
            this.m52 = new System.Windows.Forms.TextBox();
            this.m51 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.checkedListBox1 = new System.Windows.Forms.CheckedListBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.r5 = new System.Windows.Forms.TextBox();
            this.r4 = new System.Windows.Forms.TextBox();
            this.r3 = new System.Windows.Forms.TextBox();
            this.r2 = new System.Windows.Forms.TextBox();
            this.r1 = new System.Windows.Forms.TextBox();
            this.rf5 = new System.Windows.Forms.TextBox();
            this.rf4 = new System.Windows.Forms.TextBox();
            this.rf3 = new System.Windows.Forms.TextBox();
            this.rf2 = new System.Windows.Forms.TextBox();
            this.rf1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // m11
            // 
            this.m11.Location = new System.Drawing.Point(23, 150);
            this.m11.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.m11.Name = "m11";
            this.m11.Size = new System.Drawing.Size(178, 31);
            this.m11.TabIndex = 0;
            // 
            // m12
            // 
            this.m12.Location = new System.Drawing.Point(213, 150);
            this.m12.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.m12.Name = "m12";
            this.m12.Size = new System.Drawing.Size(178, 31);
            this.m12.TabIndex = 1;
            // 
            // m13
            // 
            this.m13.Location = new System.Drawing.Point(403, 150);
            this.m13.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.m13.Name = "m13";
            this.m13.Size = new System.Drawing.Size(178, 31);
            this.m13.TabIndex = 2;
            // 
            // m15
            // 
            this.m15.Location = new System.Drawing.Point(783, 150);
            this.m15.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.m15.Name = "m15";
            this.m15.Size = new System.Drawing.Size(178, 31);
            this.m15.TabIndex = 4;
            this.m15.Visible = false;
            // 
            // m14
            // 
            this.m14.Location = new System.Drawing.Point(593, 150);
            this.m14.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.m14.Name = "m14";
            this.m14.Size = new System.Drawing.Size(178, 31);
            this.m14.TabIndex = 3;
            this.m14.Visible = false;
            // 
            // m25
            // 
            this.m25.Location = new System.Drawing.Point(783, 189);
            this.m25.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.m25.Name = "m25";
            this.m25.Size = new System.Drawing.Size(178, 31);
            this.m25.TabIndex = 9;
            this.m25.Visible = false;
            // 
            // m24
            // 
            this.m24.Location = new System.Drawing.Point(593, 189);
            this.m24.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.m24.Name = "m24";
            this.m24.Size = new System.Drawing.Size(178, 31);
            this.m24.TabIndex = 8;
            this.m24.Visible = false;
            // 
            // m23
            // 
            this.m23.Location = new System.Drawing.Point(403, 189);
            this.m23.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.m23.Name = "m23";
            this.m23.Size = new System.Drawing.Size(178, 31);
            this.m23.TabIndex = 7;
            // 
            // m22
            // 
            this.m22.Location = new System.Drawing.Point(213, 189);
            this.m22.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.m22.Name = "m22";
            this.m22.Size = new System.Drawing.Size(178, 31);
            this.m22.TabIndex = 6;
            // 
            // m21
            // 
            this.m21.Location = new System.Drawing.Point(23, 189);
            this.m21.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.m21.Name = "m21";
            this.m21.Size = new System.Drawing.Size(178, 31);
            this.m21.TabIndex = 5;
            // 
            // m35
            // 
            this.m35.Location = new System.Drawing.Point(783, 228);
            this.m35.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.m35.Name = "m35";
            this.m35.Size = new System.Drawing.Size(178, 31);
            this.m35.TabIndex = 14;
            this.m35.Visible = false;
            // 
            // m34
            // 
            this.m34.Location = new System.Drawing.Point(593, 228);
            this.m34.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.m34.Name = "m34";
            this.m34.Size = new System.Drawing.Size(178, 31);
            this.m34.TabIndex = 13;
            this.m34.Visible = false;
            // 
            // m33
            // 
            this.m33.Location = new System.Drawing.Point(403, 228);
            this.m33.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.m33.Name = "m33";
            this.m33.Size = new System.Drawing.Size(178, 31);
            this.m33.TabIndex = 12;
            // 
            // m32
            // 
            this.m32.Location = new System.Drawing.Point(213, 228);
            this.m32.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.m32.Name = "m32";
            this.m32.Size = new System.Drawing.Size(178, 31);
            this.m32.TabIndex = 11;
            // 
            // m31
            // 
            this.m31.Location = new System.Drawing.Point(23, 228);
            this.m31.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.m31.Name = "m31";
            this.m31.Size = new System.Drawing.Size(178, 31);
            this.m31.TabIndex = 10;
            // 
            // m45
            // 
            this.m45.Location = new System.Drawing.Point(783, 267);
            this.m45.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.m45.Name = "m45";
            this.m45.Size = new System.Drawing.Size(178, 31);
            this.m45.TabIndex = 19;
            this.m45.Visible = false;
            // 
            // m44
            // 
            this.m44.Location = new System.Drawing.Point(593, 267);
            this.m44.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.m44.Name = "m44";
            this.m44.Size = new System.Drawing.Size(178, 31);
            this.m44.TabIndex = 18;
            this.m44.Visible = false;
            // 
            // m43
            // 
            this.m43.Location = new System.Drawing.Point(403, 267);
            this.m43.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.m43.Name = "m43";
            this.m43.Size = new System.Drawing.Size(178, 31);
            this.m43.TabIndex = 17;
            this.m43.Visible = false;
            // 
            // m42
            // 
            this.m42.Location = new System.Drawing.Point(213, 267);
            this.m42.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.m42.Name = "m42";
            this.m42.Size = new System.Drawing.Size(178, 31);
            this.m42.TabIndex = 16;
            this.m42.Visible = false;
            // 
            // m41
            // 
            this.m41.Location = new System.Drawing.Point(23, 267);
            this.m41.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.m41.Name = "m41";
            this.m41.Size = new System.Drawing.Size(178, 31);
            this.m41.TabIndex = 15;
            this.m41.Visible = false;
            // 
            // m55
            // 
            this.m55.Location = new System.Drawing.Point(783, 306);
            this.m55.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.m55.Name = "m55";
            this.m55.Size = new System.Drawing.Size(178, 31);
            this.m55.TabIndex = 24;
            this.m55.Visible = false;
            // 
            // m54
            // 
            this.m54.Location = new System.Drawing.Point(593, 306);
            this.m54.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.m54.Name = "m54";
            this.m54.Size = new System.Drawing.Size(178, 31);
            this.m54.TabIndex = 23;
            this.m54.Visible = false;
            // 
            // m53
            // 
            this.m53.Location = new System.Drawing.Point(403, 306);
            this.m53.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.m53.Name = "m53";
            this.m53.Size = new System.Drawing.Size(178, 31);
            this.m53.TabIndex = 22;
            this.m53.Visible = false;
            // 
            // m52
            // 
            this.m52.Location = new System.Drawing.Point(213, 306);
            this.m52.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.m52.Name = "m52";
            this.m52.Size = new System.Drawing.Size(178, 31);
            this.m52.TabIndex = 21;
            this.m52.Visible = false;
            // 
            // m51
            // 
            this.m51.Location = new System.Drawing.Point(23, 306);
            this.m51.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.m51.Name = "m51";
            this.m51.Size = new System.Drawing.Size(178, 31);
            this.m51.TabIndex = 20;
            this.m51.Visible = false;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(349, 36);
            this.label16.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(669, 44);
            this.label16.TabIndex = 45;
            this.label16.Text = "GAUSS-JORDAN Y GAUSS-SEIDEL";
            this.label16.Click += new System.EventHandler(this.Label16_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(147, 411);
            this.button1.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(176, 50);
            this.button1.TabIndex = 39;
            this.button1.Text = "Calcular";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // checkedListBox1
            // 
            this.checkedListBox1.BackColor = System.Drawing.Color.NavajoWhite;
            this.checkedListBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.checkedListBox1.CheckOnClick = true;
            this.checkedListBox1.FormattingEnabled = true;
            this.checkedListBox1.Items.AddRange(new object[] {
            "3x3",
            "4x4",
            "5x5"});
            this.checkedListBox1.Location = new System.Drawing.Point(23, 368);
            this.checkedListBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.checkedListBox1.Name = "checkedListBox1";
            this.checkedListBox1.Size = new System.Drawing.Size(116, 112);
            this.checkedListBox1.TabIndex = 46;
            this.checkedListBox1.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.CheckedListBox1_ItemCheck);
            this.checkedListBox1.SelectedIndexChanged += new System.EventHandler(this.CheckedListBox1_SelectedIndexChanged);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Gauss-Jordan",
            "Gauss-Seidel"});
            this.comboBox1.Location = new System.Drawing.Point(147, 368);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(176, 33);
            this.comboBox1.TabIndex = 49;
            // 
            // r5
            // 
            this.r5.Location = new System.Drawing.Point(1003, 306);
            this.r5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.r5.Name = "r5";
            this.r5.Size = new System.Drawing.Size(89, 31);
            this.r5.TabIndex = 25;
            this.r5.Visible = false;
            // 
            // r4
            // 
            this.r4.Location = new System.Drawing.Point(1003, 267);
            this.r4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.r4.Name = "r4";
            this.r4.Size = new System.Drawing.Size(89, 31);
            this.r4.TabIndex = 20;
            this.r4.Visible = false;
            // 
            // r3
            // 
            this.r3.Location = new System.Drawing.Point(1003, 228);
            this.r3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.r3.Name = "r3";
            this.r3.Size = new System.Drawing.Size(89, 31);
            this.r3.TabIndex = 15;
            this.r3.TextChanged += new System.EventHandler(this.R3_TextChanged);
            // 
            // r2
            // 
            this.r2.Location = new System.Drawing.Point(1003, 189);
            this.r2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.r2.Name = "r2";
            this.r2.Size = new System.Drawing.Size(89, 31);
            this.r2.TabIndex = 10;
            // 
            // r1
            // 
            this.r1.Location = new System.Drawing.Point(1003, 150);
            this.r1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.r1.Name = "r1";
            this.r1.Size = new System.Drawing.Size(89, 31);
            this.r1.TabIndex = 5;
            // 
            // rf5
            // 
            this.rf5.Location = new System.Drawing.Point(1135, 306);
            this.rf5.Margin = new System.Windows.Forms.Padding(4);
            this.rf5.Name = "rf5";
            this.rf5.ReadOnly = true;
            this.rf5.Size = new System.Drawing.Size(178, 31);
            this.rf5.TabIndex = 54;
            this.rf5.Visible = false;
            // 
            // rf4
            // 
            this.rf4.Location = new System.Drawing.Point(1135, 267);
            this.rf4.Margin = new System.Windows.Forms.Padding(4);
            this.rf4.Name = "rf4";
            this.rf4.ReadOnly = true;
            this.rf4.Size = new System.Drawing.Size(178, 31);
            this.rf4.TabIndex = 53;
            this.rf4.Visible = false;
            // 
            // rf3
            // 
            this.rf3.Location = new System.Drawing.Point(1135, 228);
            this.rf3.Margin = new System.Windows.Forms.Padding(4);
            this.rf3.Name = "rf3";
            this.rf3.ReadOnly = true;
            this.rf3.Size = new System.Drawing.Size(178, 31);
            this.rf3.TabIndex = 52;
            // 
            // rf2
            // 
            this.rf2.Location = new System.Drawing.Point(1135, 189);
            this.rf2.Margin = new System.Windows.Forms.Padding(4);
            this.rf2.Name = "rf2";
            this.rf2.ReadOnly = true;
            this.rf2.Size = new System.Drawing.Size(178, 31);
            this.rf2.TabIndex = 51;
            // 
            // rf1
            // 
            this.rf1.Location = new System.Drawing.Point(1135, 150);
            this.rf1.Margin = new System.Windows.Forms.Padding(4);
            this.rf1.Name = "rf1";
            this.rf1.ReadOnly = true;
            this.rf1.Size = new System.Drawing.Size(178, 31);
            this.rf1.TabIndex = 50;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(1124, 121);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(196, 25);
            this.label1.TabIndex = 55;
            this.label1.Text = "Resultados Finales";
            this.label1.Click += new System.EventHandler(this.Label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(986, 121);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(120, 25);
            this.label2.TabIndex = 56;
            this.label2.Text = "Resultados";
            // 
            // Matrices
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.NavajoWhite;
            this.ClientSize = new System.Drawing.Size(1341, 485);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.rf5);
            this.Controls.Add(this.rf4);
            this.Controls.Add(this.rf3);
            this.Controls.Add(this.rf2);
            this.Controls.Add(this.rf1);
            this.Controls.Add(this.r5);
            this.Controls.Add(this.r4);
            this.Controls.Add(this.r3);
            this.Controls.Add(this.r2);
            this.Controls.Add(this.r1);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.checkedListBox1);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.m55);
            this.Controls.Add(this.m54);
            this.Controls.Add(this.m53);
            this.Controls.Add(this.m52);
            this.Controls.Add(this.m51);
            this.Controls.Add(this.m45);
            this.Controls.Add(this.m44);
            this.Controls.Add(this.m43);
            this.Controls.Add(this.m42);
            this.Controls.Add(this.m41);
            this.Controls.Add(this.m35);
            this.Controls.Add(this.m34);
            this.Controls.Add(this.m33);
            this.Controls.Add(this.m32);
            this.Controls.Add(this.m31);
            this.Controls.Add(this.m25);
            this.Controls.Add(this.m24);
            this.Controls.Add(this.m23);
            this.Controls.Add(this.m22);
            this.Controls.Add(this.m21);
            this.Controls.Add(this.m15);
            this.Controls.Add(this.m14);
            this.Controls.Add(this.m13);
            this.Controls.Add(this.m12);
            this.Controls.Add(this.m11);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Matrices";
            this.Text = "Unidad 2 - Matrices";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox m11;
        private System.Windows.Forms.TextBox m12;
        private System.Windows.Forms.TextBox m13;
        private System.Windows.Forms.TextBox m15;
        private System.Windows.Forms.TextBox m14;
        private System.Windows.Forms.TextBox m25;
        private System.Windows.Forms.TextBox m24;
        private System.Windows.Forms.TextBox m23;
        private System.Windows.Forms.TextBox m22;
        private System.Windows.Forms.TextBox m21;
        private System.Windows.Forms.TextBox m35;
        private System.Windows.Forms.TextBox m34;
        private System.Windows.Forms.TextBox m33;
        private System.Windows.Forms.TextBox m32;
        private System.Windows.Forms.TextBox m31;
        private System.Windows.Forms.TextBox m45;
        private System.Windows.Forms.TextBox m44;
        private System.Windows.Forms.TextBox m43;
        private System.Windows.Forms.TextBox m42;
        private System.Windows.Forms.TextBox m41;
        private System.Windows.Forms.TextBox m55;
        private System.Windows.Forms.TextBox m54;
        private System.Windows.Forms.TextBox m53;
        private System.Windows.Forms.TextBox m52;
        private System.Windows.Forms.TextBox m51;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.CheckedListBox checkedListBox1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox r5;
        private System.Windows.Forms.TextBox r4;
        private System.Windows.Forms.TextBox r3;
        private System.Windows.Forms.TextBox r2;
        private System.Windows.Forms.TextBox r1;
        private System.Windows.Forms.TextBox rf5;
        private System.Windows.Forms.TextBox rf4;
        private System.Windows.Forms.TextBox rf3;
        private System.Windows.Forms.TextBox rf2;
        private System.Windows.Forms.TextBox rf1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}